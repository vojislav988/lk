-- ================================================================
--
-- @version $Id: structure.sql 2011-05-25 10:12:05 gewa $
-- @package Membership Manager Pro
-- @copyright 2015.
--
-- ================================================================
-- Database data
-- ================================================================

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`title`, `code`, `discount`, `type`, `mid`, `created`, `active`) VALUES
('10% off', '12345', '10', 'p', '5,3', '2015-03-16 15:21:27', 1);

--
-- Dumping data for table `custom_fields`
--

INSERT INTO `custom_fields` (`title`, `tooltip`, `name`, `type`, `req`, `active`, `sorting`) VALUES
('Company Name', 'Please enter your company name', 'profile00001', 'register', 1, 1, 1),
('Phone Number', 'Please enter your phone', 'profile00002', 'register', 1, 1, 2);

--
-- Dumping data for table `memberships`
--

INSERT INTO `memberships` (`title`, `description`, `price`, `days`, `period`, `trial`, `recurring`, `private`, `active`) VALUES
('Trial 7', 'This is 7 days trial membership', 0.00, 7, 'D', 1, 0, 0, 1),
('Basic 30', 'This is 30 days basic membership', 2.99, 1, 'M', 0, 1, 0, 1),
('Basic 90', 'This is 90 days basic membership', 6.99, 90, 'D', 0, 0, 0, 1),
('Platinum', 'Platinum Yearly Subscription', 49.99, 1, 'Y', 0, 1, 0, 1),
('Weekly Access', 'This is 7 days basic membership.', 1.99, 1, 'W', 0, 0, 0, 1);

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`title`, `body`, `author`, `created`, `active`) VALUES
('Welcome to our Client Area!', '&lt;p&gt;We are pleased to announce the new release of fully responsive Membership Manager Pro v 3.0&lt;/p&gt;', 'Administrator', '2015-03-14', 1);

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`txn_id`, `membership_id`, `user_id`, `rate_amount`, `tax`, `coupon`, `total`, `currency`, `date`, `pp`, `ip`, `status`) VALUES
('0', 2, 1, '2.99', 0.00, 0.00, 2.99, 'CAD', '2015-01-27 15:56:02', 'Offline', '127.0.0.1', 1),
('78910', 2, 2, '5.00', 0.00, 0.00, 5.00, 'CAD', '2015-01-12 14:12:32', 'PayPal', NULL, 0),
('11121314', 3, 3, '10.00', 0.00, 0.00, 10.00, 'CAD', '2015-02-05 16:47:36', 'Skrill', NULL, 1),
('', 2, 1, '2.99', 0.00, 0.00, 2.99, 'CAD', '2015-02-27 15:58:07', 'Stripe', '127.0.0.1', 1),
('1411052458', 4, 1, '49.99', 0.00, 0.00, 49.99, 'CAD', '2015-03-10 00:58:00', 'Stripe', '127.0.0.1', 1);