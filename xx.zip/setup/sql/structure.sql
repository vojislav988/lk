-- ================================================================
--
-- @version $Id: structure.sql 2011-05-25 10:12:05 gewa $
-- @package Membership Manager Pro
-- @copyright 2011.
--
-- ================================================================
-- Database structure
-- ================================================================

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `uid` int(11) NOT NULL DEFAULT '0',
  `mid` int(11) NOT NULL DEFAULT '0',
  `cid` int(11) NOT NULL DEFAULT '0',
  `tax` float(4,2) NOT NULL DEFAULT '0.00',
  `totaltax` float(4,2) NOT NULL DEFAULT '0.00',
  `coupon` float(4,2) NOT NULL DEFAULT '0.00',
  `total` float(4,2) NOT NULL DEFAULT '0.00',
  `originalprice` float(4,2) NOT NULL DEFAULT '0.00',
  `totalprice` float(4,2) NOT NULL DEFAULT '0.00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `abbr` varchar(2) NOT NULL,
  `name` varchar(70) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `home` tinyint(1) NOT NULL DEFAULT '0',
  `vat` decimal(5,2) NOT NULL DEFAULT '0.00',
  `sorting` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `abbrv` (`abbr`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `abbr`, `name`, `active`, `home`, `vat`, `sorting`) VALUES
(1, 'AF', 'Afghanistan', 1, 0, '0.00', 0),
(2, 'AL', 'Albania', 1, 0, '0.00', 0),
(3, 'DZ', 'Algeria', 1, 0, '0.00', 0),
(4, 'AS', 'American Samoa', 1, 0, '0.00', 0),
(5, 'AD', 'Andorra', 1, 0, '0.00', 0),
(6, 'AO', 'Angola', 1, 0, '0.00', 0),
(7, 'AI', 'Anguilla', 1, 0, '0.00', 0),
(8, 'AQ', 'Antarctica', 1, 0, '0.00', 0),
(9, 'AG', 'Antigua and Barbuda', 1, 0, '0.00', 0),
(10, 'AR', 'Argentina', 1, 0, '0.00', 0),
(11, 'AM', 'Armenia', 1, 0, '0.00', 0),
(12, 'AW', 'Aruba', 1, 0, '0.00', 0),
(13, 'AU', 'Australia', 1, 0, '0.00', 0),
(14, 'AT', 'Austria', 1, 0, '0.00', 0),
(15, 'AZ', 'Azerbaijan', 1, 0, '0.00', 0),
(16, 'BS', 'Bahamas', 1, 0, '0.00', 0),
(17, 'BH', 'Bahrain', 1, 0, '0.00', 0),
(18, 'BD', 'Bangladesh', 1, 0, '0.00', 0),
(19, 'BB', 'Barbados', 1, 0, '0.00', 0),
(20, 'BY', 'Belarus', 1, 0, '0.00', 0),
(21, 'BE', 'Belgium', 1, 0, '0.00', 0),
(22, 'BZ', 'Belize', 1, 0, '0.00', 0),
(23, 'BJ', 'Benin', 1, 0, '0.00', 0),
(24, 'BM', 'Bermuda', 1, 0, '0.00', 0),
(25, 'BT', 'Bhutan', 1, 0, '0.00', 0),
(26, 'BO', 'Bolivia', 1, 0, '0.00', 0),
(27, 'BA', 'Bosnia and Herzegowina', 1, 0, '0.00', 0),
(28, 'BW', 'Botswana', 1, 0, '0.00', 0),
(29, 'BV', 'Bouvet Island', 1, 0, '0.00', 0),
(30, 'BR', 'Brazil', 1, 0, '0.00', 0),
(31, 'IO', 'British Indian Ocean Territory', 1, 0, '0.00', 0),
(32, 'VG', 'British Virgin Islands', 1, 0, '0.00', 0),
(33, 'BN', 'Brunei Darussalam', 1, 0, '0.00', 0),
(34, 'BG', 'Bulgaria', 1, 0, '0.00', 0),
(35, 'BF', 'Burkina Faso', 1, 0, '0.00', 0),
(36, 'BI', 'Burundi', 1, 0, '0.00', 0),
(37, 'KH', 'Cambodia', 1, 0, '0.00', 0),
(38, 'CM', 'Cameroon', 1, 0, '0.00', 0),
(39, 'CA', 'Canada', 1, 1, '13.00', 1000),
(40, 'CV', 'Cape Verde', 1, 0, '0.00', 0),
(41, 'KY', 'Cayman Islands', 1, 0, '0.00', 0),
(42, 'CF', 'Central African Republic', 1, 0, '0.00', 0),
(43, 'TD', 'Chad', 1, 0, '0.00', 0),
(44, 'CL', 'Chile', 1, 0, '0.00', 0),
(45, 'CN', 'China', 1, 0, '0.00', 0),
(46, 'CX', 'Christmas Island', 1, 0, '0.00', 0),
(47, 'CC', 'Cocos (Keeling) Islands', 1, 0, '0.00', 0),
(48, 'CO', 'Colombia', 1, 0, '0.00', 0),
(49, 'KM', 'Comoros', 1, 0, '0.00', 0),
(50, 'CG', 'Congo', 1, 0, '0.00', 0),
(51, 'CK', 'Cook Islands', 1, 0, '0.00', 0),
(52, 'CR', 'Costa Rica', 1, 0, '0.00', 0),
(53, 'CI', 'Cote D''ivoire', 1, 0, '0.00', 0),
(54, 'HR', 'Croatia', 1, 0, '0.00', 0),
(55, 'CU', 'Cuba', 1, 0, '0.00', 0),
(56, 'CY', 'Cyprus', 1, 0, '0.00', 0),
(57, 'CZ', 'Czech Republic', 1, 0, '0.00', 0),
(58, 'DK', 'Denmark', 1, 0, '0.00', 0),
(59, 'DJ', 'Djibouti', 1, 0, '0.00', 0),
(60, 'DM', 'Dominica', 1, 0, '0.00', 0),
(61, 'DO', 'Dominican Republic', 1, 0, '0.00', 0),
(62, 'TP', 'East Timor', 1, 0, '0.00', 0),
(63, 'EC', 'Ecuador', 1, 0, '0.00', 0),
(64, 'EG', 'Egypt', 1, 0, '0.00', 0),
(65, 'SV', 'El Salvador', 1, 0, '0.00', 0),
(66, 'GQ', 'Equatorial Guinea', 1, 0, '0.00', 0),
(67, 'ER', 'Eritrea', 1, 0, '0.00', 0),
(68, 'EE', 'Estonia', 1, 0, '0.00', 0),
(69, 'ET', 'Ethiopia', 1, 0, '0.00', 0),
(70, 'FK', 'Falkland Islands (Malvinas)', 1, 0, '0.00', 0),
(71, 'FO', 'Faroe Islands', 1, 0, '0.00', 0),
(72, 'FJ', 'Fiji', 1, 0, '0.00', 0),
(73, 'FI', 'Finland', 1, 0, '0.00', 0),
(74, 'FR', 'France', 1, 0, '0.00', 0),
(75, 'GF', 'French Guiana', 1, 0, '0.00', 0),
(76, 'PF', 'French Polynesia', 1, 0, '0.00', 0),
(77, 'TF', 'French Southern Territories', 1, 0, '0.00', 0),
(78, 'GA', 'Gabon', 1, 0, '0.00', 0),
(79, 'GM', 'Gambia', 1, 0, '0.00', 0),
(80, 'GE', 'Georgia', 1, 0, '0.00', 0),
(81, 'DE', 'Germany', 1, 0, '0.00', 0),
(82, 'GH', 'Ghana', 1, 0, '0.00', 0),
(83, 'GI', 'Gibraltar', 1, 0, '0.00', 0),
(84, 'GR', 'Greece', 1, 0, '0.00', 0),
(85, 'GL', 'Greenland', 1, 0, '0.00', 0),
(86, 'GD', 'Grenada', 1, 0, '0.00', 0),
(87, 'GP', 'Guadeloupe', 1, 0, '0.00', 0),
(88, 'GU', 'Guam', 1, 0, '0.00', 0),
(89, 'GT', 'Guatemala', 1, 0, '0.00', 0),
(90, 'GN', 'Guinea', 1, 0, '0.00', 0),
(91, 'GW', 'Guinea-Bissau', 1, 0, '0.00', 0),
(92, 'GY', 'Guyana', 1, 0, '0.00', 0),
(93, 'HT', 'Haiti', 1, 0, '0.00', 0),
(94, 'HM', 'Heard and McDonald Islands', 1, 0, '0.00', 0),
(95, 'HN', 'Honduras', 1, 0, '0.00', 0),
(96, 'HK', 'Hong Kong', 1, 0, '0.00', 0),
(97, 'HU', 'Hungary', 1, 0, '0.00', 0),
(98, 'IS', 'Iceland', 1, 0, '0.00', 0),
(99, 'IN', 'India', 1, 0, '0.00', 0),
(100, 'ID', 'Indonesia', 1, 0, '0.00', 0),
(101, 'IQ', 'Iraq', 1, 0, '0.00', 0),
(102, 'IE', 'Ireland', 1, 0, '0.00', 0),
(103, 'IR', 'Islamic Republic of Iran', 1, 0, '0.00', 0),
(104, 'IL', 'Israel', 1, 0, '0.00', 0),
(105, 'IT', 'Italy', 1, 0, '0.00', 0),
(106, 'JM', 'Jamaica', 1, 0, '0.00', 0),
(107, 'JP', 'Japan', 1, 0, '0.00', 0),
(108, 'JO', 'Jordan', 1, 0, '0.00', 0),
(109, 'KZ', 'Kazakhstan', 1, 0, '0.00', 0),
(110, 'KE', 'Kenya', 1, 0, '0.00', 0),
(111, 'KI', 'Kiribati', 1, 0, '0.00', 0),
(112, 'KP', 'Korea, Dem. Peoples Rep of', 1, 0, '0.00', 0),
(113, 'KR', 'Korea, Republic of', 1, 0, '0.00', 0),
(114, 'KW', 'Kuwait', 1, 0, '0.00', 0),
(115, 'KG', 'Kyrgyzstan', 1, 0, '0.00', 0),
(116, 'LA', 'Laos', 1, 0, '0.00', 0),
(117, 'LV', 'Latvia', 1, 0, '0.00', 0),
(118, 'LB', 'Lebanon', 1, 0, '0.00', 0),
(119, 'LS', 'Lesotho', 1, 0, '0.00', 0),
(120, 'LR', 'Liberia', 1, 0, '0.00', 0),
(121, 'LY', 'Libyan Arab Jamahiriya', 1, 0, '0.00', 0),
(122, 'LI', 'Liechtenstein', 1, 0, '0.00', 0),
(123, 'LT', 'Lithuania', 1, 0, '0.00', 0),
(124, 'LU', 'Luxembourg', 1, 0, '0.00', 0),
(125, 'MO', 'Macau', 1, 0, '0.00', 0),
(126, 'MK', 'Macedonia', 1, 0, '0.00', 0),
(127, 'MG', 'Madagascar', 1, 0, '0.00', 0),
(128, 'MW', 'Malawi', 1, 0, '0.00', 0),
(129, 'MY', 'Malaysia', 1, 0, '0.00', 0),
(130, 'MV', 'Maldives', 1, 0, '0.00', 0),
(131, 'ML', 'Mali', 1, 0, '0.00', 0),
(132, 'MT', 'Malta', 1, 0, '0.00', 0),
(133, 'MH', 'Marshall Islands', 1, 0, '0.00', 0),
(134, 'MQ', 'Martinique', 1, 0, '0.00', 0),
(135, 'MR', 'Mauritania', 1, 0, '0.00', 0),
(136, 'MU', 'Mauritius', 1, 0, '0.00', 0),
(137, 'YT', 'Mayotte', 1, 0, '0.00', 0),
(138, 'MX', 'Mexico', 1, 0, '0.00', 0),
(139, 'FM', 'Micronesia', 1, 0, '0.00', 0),
(140, 'MD', 'Moldova, Republic of', 1, 0, '0.00', 0),
(141, 'MC', 'Monaco', 1, 0, '0.00', 0),
(142, 'MN', 'Mongolia', 1, 0, '0.00', 0),
(143, 'MS', 'Montserrat', 1, 0, '0.00', 0),
(144, 'MA', 'Morocco', 1, 0, '0.00', 0),
(145, 'MZ', 'Mozambique', 1, 0, '0.00', 0),
(146, 'MM', 'Myanmar', 1, 0, '0.00', 0),
(147, 'NA', 'Namibia', 1, 0, '0.00', 0),
(148, 'NR', 'Nauru', 1, 0, '0.00', 0),
(149, 'NP', 'Nepal', 1, 0, '0.00', 0),
(150, 'NL', 'Netherlands', 1, 0, '0.00', 0),
(151, 'AN', 'Netherlands Antilles', 1, 0, '0.00', 0),
(152, 'NC', 'New Caledonia', 1, 0, '0.00', 0),
(153, 'NZ', 'New Zealand', 1, 0, '0.00', 0),
(154, 'NI', 'Nicaragua', 1, 0, '0.00', 0),
(155, 'NE', 'Niger', 1, 0, '0.00', 0),
(156, 'NG', 'Nigeria', 1, 0, '0.00', 0),
(157, 'NU', 'Niue', 1, 0, '0.00', 0),
(158, 'NF', 'Norfolk Island', 1, 0, '0.00', 0),
(159, 'MP', 'Northern Mariana Islands', 1, 0, '0.00', 0),
(160, 'NO', 'Norway', 1, 0, '0.00', 0),
(161, 'OM', 'Oman', 1, 0, '0.00', 0),
(162, 'PK', 'Pakistan', 1, 0, '0.00', 0),
(163, 'PW', 'Palau', 1, 0, '0.00', 0),
(164, 'PA', 'Panama', 1, 0, '0.00', 0),
(165, 'PG', 'Papua New Guinea', 1, 0, '0.00', 0),
(166, 'PY', 'Paraguay', 1, 0, '0.00', 0),
(167, 'PE', 'Peru', 1, 0, '0.00', 0),
(168, 'PH', 'Philippines', 1, 0, '0.00', 0),
(169, 'PN', 'Pitcairn', 1, 0, '0.00', 0),
(170, 'PL', 'Poland', 1, 0, '0.00', 0),
(171, 'PT', 'Portugal', 1, 0, '0.00', 0),
(172, 'PR', 'Puerto Rico', 1, 0, '0.00', 0),
(173, 'QA', 'Qatar', 1, 0, '0.00', 0),
(174, 'RE', 'Reunion', 1, 0, '0.00', 0),
(175, 'RO', 'Romania', 1, 0, '0.00', 0),
(176, 'RU', 'Russian Federation', 1, 0, '0.00', 0),
(177, 'RW', 'Rwanda', 1, 0, '0.00', 0),
(178, 'LC', 'Saint Lucia', 1, 0, '0.00', 0),
(179, 'WS', 'Samoa', 1, 0, '0.00', 0),
(180, 'SM', 'San Marino', 1, 0, '0.00', 0),
(181, 'ST', 'Sao Tome and Principe', 1, 0, '0.00', 0),
(182, 'SA', 'Saudi Arabia', 1, 0, '0.00', 0),
(183, 'SN', 'Senegal', 1, 0, '0.00', 0),
(184, 'RS', 'Serbia', 1, 0, '0.00', 0),
(185, 'SC', 'Seychelles', 1, 0, '0.00', 0),
(186, 'SL', 'Sierra Leone', 1, 0, '0.00', 0),
(187, 'SG', 'Singapore', 1, 0, '0.00', 0),
(188, 'SK', 'Slovakia', 1, 0, '0.00', 0),
(189, 'SI', 'Slovenia', 1, 0, '0.00', 0),
(190, 'SB', 'Solomon Islands', 1, 0, '0.00', 0),
(191, 'SO', 'Somalia', 1, 0, '0.00', 0),
(192, 'ZA', 'South Africa', 1, 0, '0.00', 0),
(193, 'ES', 'Spain', 1, 0, '0.00', 0),
(194, 'LK', 'Sri Lanka', 1, 0, '0.00', 0),
(195, 'SH', 'St. Helena', 1, 0, '0.00', 0),
(196, 'KN', 'St. Kitts and Nevis', 1, 0, '0.00', 0),
(197, 'PM', 'St. Pierre and Miquelon', 1, 0, '0.00', 0),
(198, 'VC', 'St. Vincent and the Grenadines', 1, 0, '0.00', 0),
(199, 'SD', 'Sudan', 1, 0, '0.00', 0),
(200, 'SR', 'Suriname', 1, 0, '0.00', 0),
(201, 'SJ', 'Svalbard and Jan Mayen Islands', 1, 0, '0.00', 0),
(202, 'SZ', 'Swaziland', 1, 0, '0.00', 0),
(203, 'SE', 'Sweden', 1, 0, '0.00', 0),
(204, 'CH', 'Switzerland', 1, 0, '0.00', 0),
(205, 'SY', 'Syrian Arab Republic', 1, 0, '0.00', 0),
(206, 'TW', 'Taiwan', 1, 0, '0.00', 0),
(207, 'TJ', 'Tajikistan', 1, 0, '0.00', 0),
(208, 'TZ', 'Tanzania, United Republic of', 1, 0, '0.00', 0),
(209, 'TH', 'Thailand', 1, 0, '0.00', 0),
(210, 'TG', 'Togo', 1, 0, '0.00', 0),
(211, 'TK', 'Tokelau', 1, 0, '0.00', 0),
(212, 'TO', 'Tonga', 1, 0, '0.00', 0),
(213, 'TT', 'Trinidad and Tobago', 1, 0, '0.00', 0),
(214, 'TN', 'Tunisia', 1, 0, '0.00', 0),
(215, 'TR', 'Turkey', 1, 0, '0.00', 0),
(216, 'TM', 'Turkmenistan', 1, 0, '0.00', 0),
(217, 'TC', 'Turks and Caicos Islands', 1, 0, '0.00', 0),
(218, 'TV', 'Tuvalu', 1, 0, '0.00', 0),
(219, 'UG', 'Uganda', 1, 0, '0.00', 0),
(220, 'UA', 'Ukraine', 1, 0, '0.00', 0),
(221, 'AE', 'United Arab Emirates', 1, 0, '0.00', 0),
(222, 'GB', 'United Kingdom (GB)', 1, 0, '23.00', 999),
(224, 'US', 'United States', 1, 0, '7.50', 998),
(225, 'VI', 'United States Virgin Islands', 1, 0, '0.00', 0),
(226, 'UY', 'Uruguay', 1, 0, '0.00', 0),
(227, 'UZ', 'Uzbekistan', 1, 0, '0.00', 0),
(228, 'VU', 'Vanuatu', 1, 0, '0.00', 0),
(229, 'VA', 'Vatican City State', 1, 0, '0.00', 0),
(230, 'VE', 'Venezuela', 1, 0, '0.00', 0),
(231, 'VN', 'Vietnam', 1, 0, '0.00', 0),
(232, 'WF', 'Wallis And Futuna Islands', 1, 0, '0.00', 0),
(233, 'EH', 'Western Sahara', 1, 0, '0.00', 0),
(234, 'YE', 'Yemen', 1, 0, '0.00', 0),
(235, 'ZR', 'Zaire', 1, 0, '0.00', 0),
(236, 'ZM', 'Zambia', 1, 0, '0.00', 0),
(237, 'ZW', 'Zimbabwe', 1, 0, '0.00', 0);

--
-- Table structure for table `coupons`
--

CREATE TABLE IF NOT EXISTS `coupons` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `code` varchar(100) NOT NULL,
  `discount` varchar(4) NOT NULL DEFAULT '0',
  `type` enum('p','a') NOT NULL DEFAULT 'p',
  `mid` varchar(50) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `custom_fields`
--

CREATE TABLE IF NOT EXISTS `custom_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `tooltip` varchar(100) DEFAULT NULL,
  `name` varchar(55) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `req` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `sorting` int(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `email_templates`
--

CREATE TABLE IF NOT EXISTS `email_templates` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `help` text,
  `body` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `email_templates`
--

INSERT INTO `email_templates` (`id`, `name`, `subject`, `help`, `body`) VALUES
(1, 'Registration Email', 'Please verify your email', 'This template is used to send Registration Verification Email, when Configuration->Registration Verification is set to YES', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n&lt;tr&gt;\n&lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! Thanks for registering.&lt;/th&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n&lt;br /&gt;\nYou&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n&lt;br /&gt;\nHere are your login details. Please keep them in a safe place:&lt;br /&gt;\n&lt;br /&gt;\nUsername: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\nPassword: &lt;strong&gt;[PASSWORD]&lt;/strong&gt; &lt;hr /&gt;\nThe administrator of this site has requested all new accounts&lt;br /&gt;\nto be activated by the users who created them thus your account&lt;br /&gt;\nis currently inactive. To activate your account,&lt;br /&gt;\nplease visit the link below and enter the following:&lt;hr /&gt;\nToken: &lt;strong&gt;[TOKEN]&lt;/strong&gt;&lt;br /&gt;\nEmail: &lt;strong&gt;[EMAIL]&lt;/strong&gt; &lt;hr /&gt;\n&lt;a href=&quot;[LINK]&quot;&gt;Click here to activate tour account&lt;/a&gt;&lt;/td&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n[SITE_NAME] Team&lt;br /&gt;\n&lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n&lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;'),
(2, 'Forgot Password Email', 'Password Reset', 'This template is used for retrieving lost user password', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n&lt;tr&gt;\n&lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;New password reset from [SITE_NAME]!&lt;/th&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;Hello, &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br/&gt;\n&lt;br/&gt;\nIt seems that you or someone requested a new password for you.&lt;br/&gt;\nWe have generated a new password, as requested:&lt;br/&gt;\n&lt;br/&gt;\nYour new password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;&lt;br/&gt;\n&lt;br/&gt;\nTo use the new password you need to activate it. To do this click the link provided below and login with your new password...&lt;br/&gt;\n&lt;a href=&quot;[LINK]&quot;&gt;[LINK]&lt;/a&gt;&lt;br/&gt;\n&lt;br/&gt;\nYou can change your password after you sign in.&lt;hr/&gt;\nPassword requested from IP: [IP]&lt;/td&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br/&gt;\n[SITE_NAME] Team&lt;br/&gt;\n&lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n&lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;'),
(3, 'Welcome Mail From Admin', 'You have been registered', 'This template is used to send welcome email, when user is added by administrator', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n&lt;tr&gt;\n&lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! You have been Registered.&lt;/th&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n&lt;br /&gt;\nYou&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n&lt;br /&gt;\nHere are your login details. Please keep them in a safe place:&lt;br /&gt;\n&lt;br /&gt;\nUsername: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\nPassword: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;&lt;/td&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n[SITE_NAME] Team&lt;br /&gt;\n&lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n&lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;'),
(4, 'Default Newsletter', 'Newsletter', 'This is a default newsletter template', '&lt;div align=&quot;center&quot;&gt;\n  &lt;table style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot; border=&quot;0&quot; cellpadding=&quot;5&quot; cellspacing=&quot;5&quot; width=&quot;600&quot;&gt;\n    &lt;tbody&gt;\n&lt;tr&gt;\n&lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt; Hello [NAME]! &lt;/th&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align: left;&quot; valign=&quot;top&quot;&gt; You are receiving this email as a part of your newsletter subscription.\n&lt;hr&gt;\nHere goes your newsletter content\n&lt;hr&gt;\n[ATTACHMENT]&lt;/td&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align: left;&quot;&gt;&lt;i&gt;Thanks,&lt;br&gt;\n[SITE_NAME] Team &lt;br&gt;\n&lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/i&gt;\n&lt;hr&gt;\n&lt;span style=&quot;font-size: 11px;&quot;&gt;&lt;i&gt;To stop receiving future newsletters please login into your account and uncheck newsletter subscription box.&lt;/i&gt;&lt;/span&gt;&lt;/td&gt;\n&lt;/tr&gt;\n    &lt;/tbody&gt;\n  &lt;/table&gt;\n&lt;/div&gt;'),
(5, 'Transaction Completed', 'Payment Completed', 'This template is used to notify administrator on successful payment transaction', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n&lt;tr&gt;\n&lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello, Admin&lt;/th&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have received new payment following:&lt;br /&gt;\n&lt;br /&gt;\nUsername: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\nMembership: &lt;strong&gt;[ITEMNAME]&lt;/strong&gt;&lt;br /&gt;\nPrice: &lt;strong&gt;[PRICE]&lt;/strong&gt;&lt;br /&gt;\nStatus: &lt;strong&gt;[STATUS] &lt;/strong&gt;&lt;br /&gt;\r\nProcessor: &lt;strong&gt;[PP] &lt;/strong&gt;&lt;br /&gt;\nIP: &lt;strong&gt;[IP] &lt;/strong&gt;&lt;/td&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;&lt;em&gt;You can view this transaction from your admin panel&lt;/em&gt;&lt;/td&gt;\n&lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;'),
(6, 'Transaction Suspicious', 'Suspicious Transaction', 'This template is used to notify administrator on failed/suspicious payment transaction', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n&lt;tr&gt;\n&lt;th style=&quot;background-color:#ccc&quot;&gt;Hello, Admin&lt;/th&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td valign=&quot;top&quot; style=&quot;text-align:left&quot;&gt;The following transaction has been disabled due to suspicious activity:&lt;br /&gt;\n&lt;br /&gt;\nBuyer: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\nItem: &lt;strong&gt;[ITEM]&lt;/strong&gt;&lt;br /&gt;\nPrice: &lt;strong&gt;[PRICE]&lt;/strong&gt;&lt;br /&gt;\nStatus: &lt;strong&gt;[STATUS]&lt;/strong&gt;&lt;/td&gt;\r\nProcessor: &lt;strong&gt;[PP] &lt;/strong&gt;&lt;br /&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align:left&quot;&gt;&lt;em&gt;Please verify this transaction is correct. If it is, please activate it in the transaction section of your site&#039;s &lt;br /&gt;\nadministration control panel. If not, it appears that someone tried to fraudulently obtain products from your site.&lt;/em&gt;&lt;/td&gt;\n&lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;'),
(7, 'Welcome Email', 'Welcome', 'This template is used to welcome newly registered user when Configuration->Registration Verification and Configuration->Auto Registration are both set to YES', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n&lt;tr&gt;\n&lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! Thanks for registering.&lt;/th&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n&lt;br /&gt;\nYou&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n&lt;br /&gt;\nHere are your login details. Please keep them in a safe place:&lt;br /&gt;\n&lt;br /&gt;\nUsername: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\nPassword: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;&lt;/td&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n[SITE_NAME] Team&lt;br /&gt;\n&lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n&lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;'),
(8, 'Membership Expire 7 days', 'Your membership will expire in 7 days', 'This template is used to remind user that membership will expire in 7 days', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n&lt;tr&gt;\n&lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello, [NAME]&lt;/th&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;\n&lt;h2 style=&quot;color: rgb(255, 0, 0);&quot;&gt;Your current membership will expire in 7 days&lt;/h2&gt;\nPlease login to your user panel to extend or upgrade your membership.&lt;/td&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n[SITE_NAME] Team&lt;br /&gt;\n&lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n&lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;'),
(9, 'Membership Expired Today', 'Your membership has expired', 'This template is used to remind user that membership had expired', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n&lt;tr&gt;\n&lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello, [NAME]&lt;/th&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;\n&lt;h2 style=&quot;color: rgb(255, 0, 0);&quot;&gt;Your current membership has expired!&lt;/h2&gt;\nPlease login to your user panel to extend or upgrade your membership.&lt;/td&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n[SITE_NAME] Team&lt;br /&gt;\n&lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n&lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;'),
(10, 'Contact Request', 'Contact Inquiry', 'This template is used to send default Contact Request Form', '&lt;div align=&quot;center&quot;&gt;\n&lt;table style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot; border=&quot;0&quot; cellpadding=&quot;5&quot; cellspacing=&quot;5&quot; width=&quot;600&quot;&gt;\n    &lt;tbody&gt;\n&lt;tr&gt;\n&lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello Admin&lt;/th&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align: left;&quot; valign=&quot;top&quot;&gt;You have a new contact request: &lt;hr&gt;\n[MESSAGE] &lt;hr&gt;\nFrom: &lt;b&gt;[SENDER] - [NAME]&lt;/b&gt;&lt;br&gt;\nSubject: &lt;b&gt;[MAILSUBJECT]&lt;/b&gt;&lt;br&gt;\nSenders IP: &lt;b&gt;[IP]&lt;/b&gt;&lt;/td&gt;\n&lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;'),
(12, 'Single Email', 'Single User Email', 'This template is used to email single user', '&lt;div align=&quot;center&quot;&gt;\n  &lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n&lt;tr&gt;\n&lt;th style=&quot;background-color:#ccc&quot;&gt;Hello [NAME]&lt;/th&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td valign=&quot;top&quot; style=&quot;text-align:left&quot;&gt;Your message goes here...&lt;/td&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align:left&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n[SITE_NAME] Team&lt;br /&gt;\n&lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n&lt;/tr&gt;\n    &lt;/tbody&gt;\n  &lt;/table&gt;\n&lt;/div&gt;'),
(13, 'Notify Admin', 'New User Registration', 'This template is used to notify admin of new registration when Configuration->Registration Notification is set to YES', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n&lt;tr&gt;\n&lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello Admin&lt;/th&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have a new user registration. You can login into your admin panel to view details:&lt;hr /&gt;\nUsername: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\nName: &lt;strong&gt;[NAME]&lt;/strong&gt;&lt;br /&gt;\nIP: &lt;strong&gt;[IP]&lt;/strong&gt;&lt;/td&gt;\n&lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;'),
(14, 'Registration Pending', 'Registration Verification Pending', 'This template is used to send Registration Verification Email, when Configuration->Auto Registration is set to NO', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n&lt;tr&gt;\n&lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! Thanks for registering.&lt;/th&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n&lt;br /&gt;\nYou&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n&lt;br /&gt;\nHere are your login details. Please keep them in a safe place:&lt;br /&gt;\n&lt;br /&gt;\nUsername: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\nPassword: &lt;strong&gt;[PASSWORD]&lt;/strong&gt; &lt;hr /&gt;\nThe administrator of this site has requested all new accounts&lt;br /&gt;\nto be activated by the users who created them thus your account&lt;br /&gt;\nis currently pending verification process.&lt;/td&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n[SITE_NAME] Team&lt;br /&gt;\n&lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n&lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;'),
(15, 'User Notification', 'User Payment Completed', 'This template is used to notify user on successful payment transaction', '&lt;div align=&quot;center&quot;&gt;\n&lt;table style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot; border=&quot;0&quot; cellpadding=&quot;5&quot; cellspacing=&quot;5&quot; width=&quot;600&quot;&gt;\n    &lt;tbody&gt;\n&lt;tr&gt;\n&lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello [USERNAME]&lt;/th&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align: left;&quot; valign=&quot;top&quot;&gt;You have successfully purchased the following membership:&lt;hr/&gt;\nMembership: &lt;strong&gt;[MNAME]&lt;/strong&gt;&lt;br/&gt;\nValid Until: &lt;strong&gt;[VALID]&lt;/strong&gt;&lt;strong&gt;&lt;/strong&gt;&lt;/td&gt;\n&lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;'),
(16, 'Account Activation', 'Your account have been activated', 'This template is used to notify user when manual account activation is completed', '&lt;div align=&quot;center&quot;&gt;\n&lt;table style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot; border=&quot;0&quot; cellpadding=&quot;5&quot; cellspacing=&quot;5&quot; width=&quot;600&quot;&gt;\n    &lt;tbody&gt;\n&lt;tr&gt;\n&lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello, [NAME]! &lt;br&gt;&lt;/th&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align: left;&quot; valign=&quot;top&quot;&gt;Hello,&lt;br&gt;\n&lt;br&gt;\nYou&#039;re now a member of [SITE_NAME].&lt;br&gt;\n&lt;br&gt;\nYour account is now fully activated\n, and you may login at \n&lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;\n&lt;hr&gt;&lt;/td&gt;\n&lt;/tr&gt;\n&lt;tr&gt;\n&lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br&gt;\n[SITE_NAME] Team&lt;br&gt;\n&lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n&lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');

--
-- Table structure for table `gateways`
--

CREATE TABLE IF NOT EXISTS `gateways` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `displayname` varchar(255) NOT NULL,
  `dir` varchar(255) NOT NULL,
  `demo` tinyint(1) NOT NULL DEFAULT '1',
  `extra_txt` varchar(255) NOT NULL,
  `extra_txt2` varchar(255) NOT NULL,
  `extra_txt3` varchar(255) DEFAULT NULL,
  `extra` varchar(255) NOT NULL,
  `extra2` varchar(255) NOT NULL,
  `extra3` varchar(255) DEFAULT NULL,
  `info` text,
  `is_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gateways`
--

INSERT INTO `gateways` (`id`, `name`, `displayname`, `dir`, `demo`, `extra_txt`, `extra_txt2`, `extra_txt3`, `extra`, `extra2`, `extra3`, `info`, `is_recurring`, `active`) VALUES
(1, 'paypal', 'PayPal', 'paypal', 0, 'Paypal Email Address', 'Currency Code', 'Not in Use', 'paypal@address.com', 'CAD', '', '&lt;p&gt;&lt;a href=&quot;http://www.paypal.com/&quot; title=&quot;PayPal&quot; rel=&quot;nofollow&quot; target=&quot;_blank&quot;&gt;Click here to setup an account with Paypal&lt;/a&gt; &lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Gateway Name&lt;/strong&gt; - Enter the name of the payment provider here.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Active&lt;/strong&gt; - Select Yes to make this payment provider active. &lt;br&gt;\r\nIf this box is not checked, the payment provider will not show up in the payment provider list during checkout.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Set Live Mode&lt;/strong&gt; - If you would like to test the payment provider settings, please select No. &lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Paypal email address&lt;/strong&gt; - Enter your PayPal Business email address here. &lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Currency Code&lt;/strong&gt; - Enter your currency code here. Valid choices are: &lt;/p&gt;\r\n	&lt;ul&gt;\r\n&lt;li&gt; USD (U.S. Dollar)&lt;/li&gt;\r\n&lt;li&gt; EUR (Euro) &lt;/li&gt;\r\n&lt;li&gt; GBP (Pound Sterling) &lt;/li&gt;\r\n&lt;li&gt; CAD (Canadian Dollar) &lt;/li&gt;\r\n&lt;li&gt; JPY (Yen). &lt;/li&gt;\r\n&lt;li&gt; If omitted, all monetary fields will use default system setting Currency Code. &lt;/li&gt;\r\n	&lt;/ul&gt;\r\n&lt;p&gt;&lt;strong&gt;Not in Use&lt;/strong&gt; - This field it&#039;s not in use. Leave it empty. &lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;IPN Url&lt;/strong&gt; - If using recurring payment method, you need to set up and activate the IPN Url in your account: &lt;/p&gt;', 1, 1),
(2, 'skrill', 'Skrill', 'skrill', 1, 'Skrill Email Address', 'Currency Code', 'Secret Passphrase', 'moneybookers@address.com', 'EUR', 'mypassphrase', '&lt;p&gt;&lt;a href=&quot;http://www.skrill.com/&quot; title=&quot;http://www.skrill.com/&quot; rel=&quot;nofollow&quot;&gt;Click here to setup an account with Skrill&lt;/a&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Gateway Name&lt;/strong&gt; - Enter the name of the payment provider here.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Active&lt;/strong&gt; - Select Yes to make this payment provider active. &lt;br&gt;\r\nIf this box is not checked, the payment provider will not show up in the payment provider list during checkout.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Set Live Mode&lt;/strong&gt; - If you would like to test the payment provider settings, please select No. &lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;MoneyBookers email address&lt;/strong&gt; - Enter your MoneyBookers email address here. &lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Secret Passphrase&lt;/strong&gt; - This field must be set at Moneybookers.com.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;IPN Url&lt;/strong&gt; - If using recurring payment method, you need to set up and activate the IPN Url in your account: &lt;/p&gt;', 1, 1),
(3, 'stripe', 'Stripe', 'stripe', 1, 'Stripe Secret Key', 'Currency Code', NULL, 'sk_test_6sDE6weBXgEuHbrjZKyG5MlQ', 'CAD', 'pk_test_vRosykAcmL59P2r7H9hziwrg', '&lt;p&gt;&lt;a href=&quot;https://stripe.com/ca&quot; title=&quot;https://stripe.com/ca&quot; rel=&quot;nofollow&quot;&gt;Click here to setup an account with Stripe&lt;/a&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Gateway Name&lt;/strong&gt; - Enter the name of the payment provider here.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Active&lt;/strong&gt; - Select Yes to make this payment provider active. &lt;br&gt;\r\n  If this box is not checked, the payment provider will not show up in the payment provider list during checkout.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Set Live Mode&lt;/strong&gt; - To test Stripe, use your test keys instead of live ones.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;API Keys&lt;/strong&gt; - To obtain your API Keys:&lt;/p&gt;\r\n&lt;ul&gt;\r\n  &lt;li&gt; 1. Log into the Dashboard at &lt;a href=&quot;https://stripe.com/ca&quot; target=&quot;_blank&quot;&gt;https://stripe.com/ca&lt;/a&gt;&lt;/li&gt;\r\n  &lt;li&gt; 2. Select Account Settings under Your Account in the main menu on the left &lt;/li&gt;\r\n  &lt;li&gt; 3. Click API Keys&lt;/li&gt;\r\n  &lt;li&gt; 4. Your keys will be displayed &lt;/li&gt;\r\n\r\n&lt;p&gt;You should use test keys first to verify, that everything is working smoothly, before going live.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;IPN Url&lt;/strong&gt; - This option it&#039;s not being used.&lt;/p&gt;\r\n&lt;/ul&gt;', 0, 1),
(4, 'payfast', 'PayFast', 'payfast', 1, 'Merchant ID', 'Merchant Key', 'PassPhrase', '', '', NULL, '&lt;p&gt;&lt;a href=&quot;https://www.payfast.co.za/&quot; title=&quot;https://www.payfast.co.za/&quot; rel=&quot;nofollow&quot;&gt;Click here to setup an account with PayFast&lt;/a&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Gateway Name&lt;/strong&gt; - Enter the name of the payment provider here.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Active&lt;/strong&gt; - Select Yes to make this payment provider active. &lt;br&gt;\r\n&lt;p&gt;&lt;strong&gt;PassPhrase&lt;/strong&gt; - ONLY INSERT A VALUE INTO THE SECURE PASSPHRASE IF YOU HAVE SET THIS ON THE INTEGRATION PAGE OF THE LOGGED IN AREA OF THE PAYFAST WEBSITE!!!!!.&lt;/p&gt;\r\nIf this box is not checked, the payment provider will not show up in the payment provider list during checkout.\r\n&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Set Live Mode&lt;/strong&gt; - To test PayFast, use your test keys instead of live ones.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;API Keys&lt;/strong&gt; - To obtain your API Keys:&lt;/p&gt;\r\n&lt;ul&gt;\r\n  &lt;li&gt; 1. Log into the Dashboard at &lt;a href=&quot;https://www.payfast.co.za/user/login&quot; target=&quot;_blank&quot;&gt;https://www.payfast.co.za/user/login&lt;/a&gt;&lt;/li&gt;\r\n  &lt;li&gt; 2. Select Account Settings under Your Account in the main menu on the left &lt;/li&gt;\r\n  &lt;li&gt; 3. Click API Keys&lt;/li&gt;\r\n  &lt;li&gt; 4. Your keys will be displayed &lt;/li&gt;\r\n  &lt;p&gt;You should use test keys first to verify, that everything is working smoothly, before going live.&lt;/p&gt;\r\n  &lt;p&gt;&lt;strong&gt;IPN Url&lt;/strong&gt; - This option it''s not being used.&lt;/p&gt;\r\n&lt;/ul&gt;', 0, 1);

--
-- Table structure for table `memberships`
--

CREATE TABLE IF NOT EXISTS `memberships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` float(10,2) NOT NULL DEFAULT '0.00',
  `days` int(5) NOT NULL DEFAULT '0',
  `period` varchar(1) NOT NULL DEFAULT 'D',
  `trial` tinyint(1) NOT NULL DEFAULT '0',
  `recurring` tinyint(1) NOT NULL DEFAULT '0',
  `private` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(55) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `body` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `author` varchar(55) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `created` date NOT NULL DEFAULT '0000-00-00',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


--
-- Dumping data for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `txn_id` varchar(100) DEFAULT NULL,
  `membership_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rate_amount` varchar(255) NOT NULL,
  `tax` float(4,2) NOT NULL DEFAULT '0.00',
  `coupon` float(4,2) NOT NULL DEFAULT '0.00',
  `total` float(4,2) NOT NULL DEFAULT '0.00',
  `currency` varchar(4) DEFAULT NULL,
  `date` datetime NOT NULL,
  `pp` enum('PayPal','Skrill','Stripe','PayFast') DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `site_name` varchar(50) DEFAULT NULL,
  `site_email` varchar(40) DEFAULT NULL,
  `site_url` varchar(200) DEFAULT NULL,
  `site_dir` varchar(100) DEFAULT NULL,
  `reg_allowed` tinyint(1) NOT NULL DEFAULT '1',
  `user_limit` tinyint(1) NOT NULL DEFAULT '0',
  `reg_verify` tinyint(1) NOT NULL DEFAULT '0',
  `notify_admin` tinyint(1) NOT NULL DEFAULT '0',
  `auto_verify` tinyint(1) NOT NULL DEFAULT '0',
  `perpage` tinyint(1) NOT NULL DEFAULT '12',
  `thumb_w` varchar(4) NOT NULL,
  `thumb_h` varchar(4) NOT NULL,
  `backup` varchar(60) DEFAULT NULL,
  `logo` varchar(40) DEFAULT NULL,
  `currency` varchar(4) DEFAULT NULL,
  `cur_symbol` varchar(8) DEFAULT NULL,
  `dsep` varchar(2) DEFAULT ',',
  `tsep` varchar(2) DEFAULT '.',
  `enable_tax` tinyint(1) NOT NULL DEFAULT '0',
  `long_date` varchar(50) DEFAULT NULL,
  `short_date` varchar(50) DEFAULT NULL,
  `inv_info` text,
  `inv_note` text,
  `mailer` enum('PHP','SMTP','SMAIL') NOT NULL DEFAULT 'PHP',
  `smtp_host` varchar(100) DEFAULT NULL,
  `smtp_user` varchar(50) DEFAULT NULL,
  `smtp_pass` varchar(50) DEFAULT NULL,
  `smtp_port` varchar(6) DEFAULT NULL,
  `is_ssl` tinyint(1) NOT NULL DEFAULT '0',
  `sendmail` varchar(150) DEFAULT NULL,
  `version` varchar(5) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`site_name`, `site_email`, `site_url`, `site_dir`, `reg_allowed`, `user_limit`, `reg_verify`, `notify_admin`, `auto_verify`, `perpage`, `thumb_w`, `thumb_h`, `backup`, `logo`, `currency`, `cur_symbol`, `dsep`, `tsep`, `enable_tax`, `long_date`, `short_date`, `inv_info`, `inv_note`, `mailer`, `smtp_host`, `smtp_user`, `smtp_pass`, `smtp_port`, `is_ssl`, `sendmail`, `version`) VALUES
('', '', '', '', 1, 0, 1, 0, 1, 12, '120', '120', '15-Mar-2015_22-49-51.sql', '', 'CAD', '$', ',', '.', 1, '%A %d %B %Y %H:%M', '%d %b %Y', '&lt;p&gt;&lt;b&gt;ABC Company Pty Ltd&lt;/b&gt;&lt;br&gt;123 Burke Street, Toronto ON, CANADA&lt;br&gt;Tel : (416) 1234-5678, Fax : (416) 1234-5679, Email : sales@abc-company.com&lt;br&gt;Web Site : www.abc-company.com&lt;/p&gt;', '&lt;p&gt;TERMS &amp;amp; CONDITIONS&lt;br&gt;1. Interest may be levied on overdue accounts. &lt;br&gt;2. Goods sold are not returnable or refundable\n&lt;/p&gt;', 'PHP', '', '', '', '0', 0, 'afasfasf', '3.00');

--
-- Dumping data for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `membership_id` tinyint(3) NOT NULL DEFAULT '0',
  `mem_expire` datetime DEFAULT '0000-00-00 00:00:00',
  `trial_used` tinyint(1) NOT NULL DEFAULT '0',
  `email` varchar(32) NOT NULL,
  `fname` varchar(32) NOT NULL,
  `lname` varchar(32) NOT NULL,
  `address` varchar(150) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `country` varchar(4) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `zip` varchar(20) DEFAULT NULL,
  `token` varchar(40) NOT NULL DEFAULT '0',
  `cookie_id` varchar(64) NOT NULL DEFAULT '0',
  `newsletter` tinyint(1) NOT NULL DEFAULT '0',
  `userlevel` tinyint(1) NOT NULL DEFAULT '1',
  `notes` text,
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  `lastlogin` datetime DEFAULT '0000-00-00 00:00:00',
  `lastip` varchar(16) DEFAULT '0',
  `avatar` varchar(150) DEFAULT NULL,
  `custom_fields` text,
  `active` enum('y','n','t','b') NOT NULL DEFAULT 'n',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;