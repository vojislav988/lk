<?php
$name='DejaVuSerif-BoldItalic';
$type='TTF';
$desc=array (
  'Ascent' => 939,
  'Descent' => -236,
  'CapHeight' => 939,
  'Flags' => 262212,
  'FontBBox' => '[-906 -389 1754 1235]',
  'ItalicAngle' => -11,
  'StemV' => 165,
  'MissingWidth' => 600,
);
$up=-63;
$ut=44;
$ttffile='W:/public_html/fm3/lib/mPdf/ttfonts/DejaVuSerif-BoldItalic.ttf';
$TTCfontID='0';
$originalsize=295360;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavuserifBI';
$panose=' 0 0 2 6 8 3 5 3 5 b 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>