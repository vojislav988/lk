<?php
$name='DejaVuSerif';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 4,
  'FontBBox' => '[-770 -347 1679 1242]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 600,
);
$up=-63;
$ut=44;
$ttffile='W:/public_html/fm3/lib/mPdf/ttfonts/DejaVuSerif.ttf';
$TTCfontID='0';
$originalsize=330052;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavuserif';
$panose=' 0 0 2 6 6 3 5 6 5 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>